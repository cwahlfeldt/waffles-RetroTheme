<?php if ( is_sidebar_active('primary_widget_area') ) : ?>
        <div id="primary" class="widget-area">
        
                <div id="toggle-button">
                    <a id="hideshow" onclick="toggle_visibility('hide-show')">&nbsp;</a>
                </div>
         <div id="hide-show">

            <div id="social-access">
                <a href="https://www.facebook.com/cwahlfeldt" target="_blank"><img src="wp-content/uploads/2014/05/facebook.png" /></a>
                <a href="https://plus.google.com/116075397322993264768/about" target="_blank"><img src="wp-content/uploads/2014/05/google.png" /></a>
                <a href="https://www.linkedin.com/pub/christopher-wahlfeldt/74/794/214" target="_blank"><img src="wp-content/uploads/2014/05/linkedin.png" /></a>
                <a href="https://twitter.com/ChrisWahlfeldt" target="_blank"><img src="wp-content/uploads/2014/05/twitter.png" /></a>
            </div>

            <ul class="xoxo">
              <div id="inner-sidebar">
                <?php dynamic_sidebar('primary_widget_area'); ?>
              </div>
            </ul>
            
          </div>
        </div><!-- #primary .widget-area -->
<?php endif; ?>       
 
<?php if ( is_sidebar_active('secondary_widget_area') ) : ?>
        <div id="secondary" class="widget-area">
            <ul class="xoxo">
                <?php dynamic_sidebar('secondary_widget_area'); ?>
            </ul>
        </div><!-- #secondary .widget-area -->
<?php endif; ?>